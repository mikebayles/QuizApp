//
//  GradeCollection.m
//  QuizClient
//
//  Created by Mike Bayles on 12/11/13.
//  Copyright (c) 2013 Mike Bayles. All rights reserved.
//

#import "GradeCollection.h"


@implementation GradeCollection

@end
