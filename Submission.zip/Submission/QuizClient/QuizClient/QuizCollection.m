//
//  QuizCollection.m
//  QuizClient
//
//  Created by Mike Bayles on 11/2/13.
//  Copyright (c) 2013 Mike Bayles. All rights reserved.
//

#import "QuizCollection.h"

@implementation QuizCollection

@end
