//
//  TeacherGradeViewController.h
//  QuizClient
//
//  Created by Mike Bayles on 12/10/13.
//  Copyright (c) 2013 Mike Bayles. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeacherGradeViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tblGrades;

@end
