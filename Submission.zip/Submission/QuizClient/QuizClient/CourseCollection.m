//
//  CourseCollection.m
//  QuizClient
//
//  Created by Mike Bayles on 12/8/13.
//  Copyright (c) 2013 Mike Bayles. All rights reserved.
//

#import "CourseCollection.h"

@implementation CourseCollection

@end
